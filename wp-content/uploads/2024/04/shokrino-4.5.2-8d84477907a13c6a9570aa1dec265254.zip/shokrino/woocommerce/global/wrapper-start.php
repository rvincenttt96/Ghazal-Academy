<?php
/**
 * Content wrappers
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/wrapper-start.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$template = wc_get_theme_slug_for_templates();
?>
    <div class="container">
    <?php
    if (!is_singular('product')) {
    if ( apply_filters( 'woocommerce_show_page_title', true ) ) { ?>
        <header class="shkrn-archive-title-desc flex-center woocommerce-products-header">
            <h1 class="woocommerce-products-header__title page-title"><?php echo woocommerce_page_title(); ?></h1>
            <?php do_action( 'woocommerce_archive_description' ); ?>
        </header>
    <?php } } ?>
    <nav class="breadcrumb-box-shkrn">
        <?php shkrn_bread_crumb(); ?>
    </nav>
    <div class="single-page-shkrn">
        <main id="primary" class="single-page-main-part wc-page-shkrn" role="main">