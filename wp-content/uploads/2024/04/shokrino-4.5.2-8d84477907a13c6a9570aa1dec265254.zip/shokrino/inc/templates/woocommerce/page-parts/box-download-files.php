<?php
defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
$current_user_id = wp_get_current_user()->ID;
$downloads = wc_get_customer_available_downloads($current_user->ID);
?>
<section class="anchor-list-on-product-shkrn box-dl-shkrn-course posts-section-shkrn flex-center">
    <div class="posts-section-header flex-center">
        <div class="posts-title-shkrn flex-center">
            <h2><?php esc_html_e('Course Downloady files', 'shokrino'); ?></h2>
            <h5>&#160;&#160;&#160;&#160;&#160;&#160;<?php esc_html_e('This section is only visible to course students', 'shokrino'); ?></h5>
        </div>
    </div>
        <div class="box-download-files flex-center">
            <?php foreach ($downloads as $download_item_box) {?>
                <?php if ($download_item_box['product_id'] === get_the_ID()) { ?>
                    <tr>
                        <td><?php echo '<a href="' . $download_item_box['download_url'] . '" class="item-btn-download-shkrn flex-center"><svg xmlns="http://www.w3.org/2000/svg" height="20px" fill="var(--shkrn-var-color-light-dark-text)" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M245.4 379.1C248.4 382.7 252.2 384 256 384s7.594-1.344 10.62-4.047l144-128c6.594-5.859 7.219-15.98 1.344-22.58c-5.875-6.625-16.06-7.234-22.59-1.328L272 332.4V16C272 7.156 264.8 0 256 0S240 7.156 240 16v316.4L122.6 228C116.1 222.1 105.9 222.8 100 229.4C94.16 235.1 94.78 246.1 101.4 251.1L245.4 379.1zM448 320h-48c-8.836 0-16 7.162-16 16c0 8.836 7.164 16 16 16H448c17.67 0 32 14.33 32 32v64c0 17.67-14.33 32-32 32H64c-17.67 0-32-14.33-32-32v-64c0-17.67 14.33-32 32-32h48C120.8 352 128 344.8 128 336C128 327.2 120.8 320 112 320H64c-35.35 0-64 28.65-64 64v64c0 35.35 28.65 64 64 64h384c35.35 0 64-28.65 64-64v-64C512 348.7 483.3 320 448 320zM440 416c0-13.25-10.75-24-24-24s-24 10.75-24 24s10.75 24 24 24S440 429.3 440 416z"/></svg> ' . $download_item_box['file']['name'] . ' </a>'; ?></td>
                    </tr>
                <?php } else { ?>
                    <style>
                        .box-dl-shkrn-course {
                            display: none;
                        }
                    </style>
                <?php } ?>
            <?php } ?>
        </div>
</section>
