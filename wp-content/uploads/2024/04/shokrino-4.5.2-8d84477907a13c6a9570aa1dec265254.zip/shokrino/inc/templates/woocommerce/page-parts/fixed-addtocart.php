<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$fixed_add_to_cart_text = shkrn_options('fixed_add_to_cart_text');
$fixed_addtocart = shkrn_options('fixed_addtocart');
if ($fixed_addtocart) {
        $id = $product->get_id();
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
        }
        if (wc_customer_bought_product($current_user->user_email, $current_user->ID, $id)) {
        } else {
                if (shkrn_stock_status_product($id) !== "outofstock") { ?>
                    <a href="<?php echo do_shortcode("[add_to_cart_url id=$id]"); ?>" class="fixed-cartbtn shkrn-except-desktop">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><defs><style>.fa-secondary{opacity:.4}</style></defs><path class="fa-primary" d="M576 224H0V128H576V224z"/><path class="fa-secondary" d="M512 32C547.3 32 576 60.65 576 96V128H0V96C0 60.65 28.65 32 64 32H512zM576 416C576 451.3 547.3 480 512 480H64C28.65 480 0 451.3 0 416V224H576V416zM112 352C103.2 352 96 359.2 96 368C96 376.8 103.2 384 112 384H176C184.8 384 192 376.8 192 368C192 359.2 184.8 352 176 352H112zM240 384H368C376.8 384 384 376.8 384 368C384 359.2 376.8 352 368 352H240C231.2 352 224 359.2 224 368C224 376.8 231.2 384 240 384z"/></svg>&nbsp;&nbsp;
                        <?php if (!empty($fixed_add_to_cart_text)) {
                            echo $fixed_add_to_cart_text;
                        } else { ?>
                            <?php esc_html_e('همین الان ثبت نام کن', 'shokrino'); ?>
                        <?php } ?>
                    </a>
                <?php } ?>
        <?php }
}