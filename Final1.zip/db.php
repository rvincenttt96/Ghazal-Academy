<?php
// تنظیمات اتصال به دیتابیس
<?php
$host = 'localhost';
$db   = 'ghazali1_AnnouncementPanel';
$user = 'ghazali1_AnnouncementPanel';
$pass = 'pVYZhVVEH7CSbBrzAu5E';

// ... بقیه کدهای اتصال PDO دقیقاً سر جاش بمونه ...
?>

$dsn = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     die(json_encode(["status" => "error", "message" => "اتصال به دیتابیس برقرار نشد: " . $e->getMessage()]));
}
?>