<?php
/**
 * PHP Backend API for Ghazal Notification Panel
 * File: send-notification.php
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(); }

require_once 'db.php';
require_once 'services.php';

// کدهای مچ‌گیری تستی با موفقیت حذف شدند! 

$data = json_decode(file_get_contents('php://input'), true);
$message = trim($data['message'] ?? '');
$destinations = $data['destinations'] ?? [];
$targetClasses = $data['classes'] ?? [];
$targetStudents = $data['students'] ?? [];

if (empty($message)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "متن پیام خالی است."]);
    exit();
}

try {
    $pdo->beginTransaction();

    // ۱. ثبت لاگ اولیه پیام
    $stmtLog = $pdo->prepare("INSERT INTO message_logs (raw_message, destinations, status) VALUES (?, ?, 'pending')");
    $stmtLog->execute([$message, implode(',', $destinations)]);
    $messageLogId = $pdo->lastInsertId();

// ۲. منطق ارسال پیامک (فقط اگر sms انتخاب شده باشد)
    if (in_array('sms', $destinations)) {
        foreach ($targetStudents as $stdKey) {
            // تغییر اول: اضافه کردن s.id به دستور SELECT برای گرفتن آیدی عددی
            $stmt = $pdo->prepare("SELECT s.id, s.name as sName, p.name as pName, p.phone FROM students s JOIN parents p ON s.parent_id = p.id WHERE s.student_key = ?");
            $stmt->execute([$stdKey]);
            $rec = $stmt->fetch();

            if ($rec) {
                // ارسال واقعی پیامک با متغیر parent
                $smsResult = sendFarazSMS($rec['phone'], "yCT20au05o", ["parent" => $rec['pName'] ?? 'والدین گرامی']);
                
                // تغییر دوم: استفاده از آیدی عددی ($rec['id']) به جای آیدی متنی ($stdKey)
                $pdo->prepare("INSERT INTO message_recipients (message_log_id, student_id) VALUES (?, ?)")
                    ->execute([$messageLogId, $rec['id']]);
            }
        }
    }

    // ۳. منطق ارسال به کانال رسمی بله
    if (in_array('bale_channel', $destinations)) {
        // آیدی کانال بله آموزشگاه را اینجا وارد کن (با @ شروع شود)
        // مثلا: "@ghazal_institute" یا آیدی عددی کانال
        $baleChannelId = "@ghazallanguageacademy"; 
        
        // چون پیام کانال نیازی به شخصی‌سازی برای هر دانش‌آموز نداره، 
        // همون متن اصلی رو یک بار می‌فرستیم تو کانال
        sendBaleMessage($baleChannelId, $message);
    }

    $pdo->commit();
    echo json_encode(["status" => "success", "log_id" => $messageLogId]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
// ۴. منطق ارسال به کانال رسمی ایتا
    if (in_array('eitaa_channel', $destinations)) {
        // شناسه کانال ایتا (همون شناسه‌ای که تو پنل ایتاار به کانال اختصاص داده شده)
        $eitaaChannelId = "10949564"; 
        
        sendEitaaMessage($eitaaChannelId, $message);
    }

    // ۵. منطق ارسال به گروه‌های کلاسی ایتا
    if (in_array('eitaa_groups', $destinations)) {
        foreach ($targetClasses as $clsVal) {
            // شما باید شناسه گروه‌های کلاسی که تو پنل ایتاار ثبت کردید رو به کلاس‌ها متصل کنید
            // فعلاً به صورت ساده با یک سوییچ هندلش می‌کنیم:
            $groupChatId = "";
            
            if ($clsVal === "الف") {
                $groupChatId = "class_a_group_id_in_eitaayar";
            } elseif ($clsVal === "ب") {
                $groupChatId = "class_b_group_id_in_eitaayar";
            } elseif ($clsVal === "ج") {
                $groupChatId = "class_c_group_id_in_eitaayar";
            }
            
            // اگر آیدی گروه برای این کلاس تنظیم شده بود، پیام رو فقط تو همون گروه بفرست
            if (!empty($groupChatId)) {
                // یک کار جذاب: کلمه {نام_کلاس} تو متن رو به صورت خودکار با اسم کلاس جایگزین می‌کنیم
                $personalizedMessage = str_replace("{نام_کلاس}", "کلاس " . $clsVal, $message);
                
                sendEitaaMessage($groupChatId, $personalizedMessage);
            }
        }
    }